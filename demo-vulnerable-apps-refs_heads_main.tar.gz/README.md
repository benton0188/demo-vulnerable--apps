# Demonstration applications with vulnerable dependencies

This repository contains small examples that include dependencies
with known vulnerabilities.  The examples are safe to run as they
do not actually use any functionality from the vulnerable dependencies.
